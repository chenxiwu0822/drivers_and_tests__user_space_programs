/*
	int select(int maxfdp, fd_set *readfds, fd_set *writefds, fd_set *errorfds, struct timeval *timeout);

第一，struct fd_set可以理解为一个集合，这个集合中存放的是文件描述符(filedescriptor)，即文件句柄，这可以是我们所说的普通意义的文件，
当然Unix下任何设备、管道、FIFO等都是文件形式，全部包括在内，所以毫无疑问一个socket就是一个文件，socket句柄就是一个文件描述符。
fd_set集合可以通过一些宏由人为来操作，比如清空集合: FD_ZERO(fd_set *)；

将一个给定的文件描述符加入集合之中: FD_SET(int ,fd_set*)；
将一个给定的文件描述符从集合中删除: FD_CLR(int,fd_set*)；
检查集合中指定的文件描述符是否可以读写: FD_ISSET(int ,fd_set* )



具体解释select的参数：
int maxfdp:     是一个整数值，是指集合中所有文件描述符的范围，即所有文件描述符的最大值加1，不能错！在Windows中这个参数的值无所谓，可以设置不正确。

fd_set*readfds: 是指向fd_set结构的指针，这个集合中应该包括文件描述符，我们是要监视这些文件描述符的读变化的，即我们关心是否可以从这些文件中读取数据了，如果这个集合中有一个文件可读，select就会返回一个大于0的值，表示有文件可读，如果没有可读的文件，则根据timeout参数再判断是否超时，若超出timeout的时间，select返回0，若发生错误返回负值。可以传入NULL值，表示不关心任何文件的读变化。

fd_set*writefds: 是指向fd_set结构的指针，这个集合中应该包括文件描述符，我们是要监视这些文件描述符的写变化的，即我们关心是否可以向这些文件中写入数据了，如果这个集合中有一个文件可写，select就会返回一个大于0的值，表示有文件可写，如果没有可写的文件，则根据timeout参数再判断是否超时，若超出timeout的时间，select返回0，若发生错误返回负值。可以传入NULL值，表示不关心任何文件的写变化。

fd_set *errorfds: 同上面两个参数的意图，用来监视文件错误异常。

struct timeval *timeout: 是select的超时时间，这个参数至关重要，它可以使select处于三种状态，
第一，若将NULL以形参传入，即不传入时间结构，就是将select置于阻塞状态，一定等到监视文件描述符集合中某个文件描述符发生变化为止；
第二，若将时间值设为0秒0毫秒，就变成一个纯粹的非阻塞函数，不管文件描述符是否有变化，都立刻返回继续执行，文件无变化返回0，有变化返回一个正值；
第三，timeout的值大于0，这就是等待的超时时间，即select在timeout时间内阻塞，超时时间之内有事件到来就返回了，否则在超时后不管怎样一定返回，返回值同上述。


返回值：
负值：select错误 
正值：某些文件可读写或出错 
0：等待超时，没有可读写或错误的文件

在有了select后可以 写出像样的 网络程序来！举个简单的例子，就是从网络上接受数据写入一个文件中。
*/
//例子：
main() 
{ 
    int sock; 
    FILE *fp; 
    struct fd_set fds; 
    struct timeval timeout={3,0}; //select等待3秒，3秒轮询，要非阻塞就置0 
    char buffer[256]={0}; //256字节的接收缓冲区 

    /* 假定已经建立UDP连接，具体过程不写，简单，当然TCP也同理，主机ip和port都已经给定，要写的文件已经打开 
    sock=socket(...); 
    bind(...); 

    fp=fopen(...); */ 

    while(1) 
	{ 
        FD_ZERO(&fds); //每次循环都要清空集合，否则不能检测描述符变化
        FD_SET(sock,&fds); //添加描述符 
        FD_SET(fp,&fds); //同上
        maxfdp=sock>fp?sock+1:fp+1;    //描述符最大值加1
        switch(select(maxfdp,&fds,&fds,NULL,&timeout))   //select使用 
        { 
            case -1: exit(-1);break; //select错误，退出程序 
            case 0:           break; //再次轮询
            default: 
                  if(FD_ISSET(sock,&fds)) //测试sock是否可读，即是否网络上有数据
                  { 
                        recvfrom(sock,buffer,256,.....);//接受网络数据 
                        if(FD_ISSET(fp,&fds)) //测试文件是否可写 
                            fwrite(fp,buffer...);//写入文件 
                         buffer清空; 
                   }
          }
     }
}




//注意select被信号中断的处理不能等同于出错返回,而应该继续select
int readPort(int fd, char *buf, int len, int maxwaittime)	//读数据，参数为串口，BUF，长度，超时时间
{
     int no= 0;
	 int rc;
     int rcnum = len;
     struct timeval tv;
      
     fd_set readfd;
     tv.tv_sec  = maxwaittime;		//秒数
     tv.tv_usec =0;  				//毫秒数

     FD_ZERO(&readfd);
     FD_SET(fd, &readfd);

     rc = select(fd+1, &readfd, NULL, NULL, &tv);

     if(rc>0)
     {
          while(len)
          {
           rc = read(fd,&buf[no],1);
           if(rc>0)
                no=no+1;
           len=len-1;   
          }
          //if(no!=rcnum)
          //	return -1;		//如果收到的长度与期望长度不一样，返回-1
          return rcnum;      	//收到长度与期望长度一样，返回长度
     }
     else
     {
         return -1;
     }
     return rc;
}
