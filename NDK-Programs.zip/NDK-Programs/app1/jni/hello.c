#include <stdio.h>
int main()
{
    printf("Hello Android!\n");
    return 0;
}
