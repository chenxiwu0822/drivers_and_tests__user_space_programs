/*
找到了L4V2 api官方测试程序，弄了半天总算有点明白了。稍微做了改动。

这个程序是使用YUV格式保存，并且通过stdio输出，这样做的目的是方便重定向到下一个转换程序。
但是对于着急需要测试和入门学习的人来说，就是隔靴搔痒了。

所以，我将程序稍微修改了一下: 当只要求拍摄一幅图片时，就自动将其保存为bmp文件，这样就可以快速对摄像头进行测试。


这个程序没有库的依赖，是最简单和轻量级的。
这里我的摄像头是video4，也可以单独指定。
*/ 

#ifndef __V4LGRAB_H__
#define __V4LGRAB_H__

#include <stdio.h>
   
#define FALSE 0
#define TRUE 1
 
typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef unsigned long  DWORD;
 
/* */
#pragma pack(push)
#pragma pack(2) 
typedef struct tag_bit_map_file_header {
     WORD     bfType;		// the flag of bmp, value is "BM"
     DWORD    bfSize;		// size BMP file ,unit is bytes
     DWORD    bfReserved;	// 0
     DWORD    bfOffBits;	// must be 54
} bit_map_file_header;
 
  
typedef struct tag_bit_map_info_header {
     DWORD    biSize;		// must be 0x28
     DWORD    biWidth;		//
     DWORD    biHeight;		//
     WORD     biPlanes;		// must be 1
     WORD     biBitCount;	//
     DWORD    biCompression;	//
     DWORD    biSizeImage;	//
     DWORD    biXPelsPerMeter;	//
     DWORD    biYPelsPerMeter;	//
     DWORD    biClrUsed;	//
     DWORD    biClrImportant;	//
 
} bit_map_info_header;
 
typedef struct tagRGBQUAD{
 
     BYTE rgbBlue;
     BYTE rgbGreen;
     BYTE rgbRed;
     BYTE rgbReserved;
 
}RGBQUAD;
 
#pragma pack(pop) 
int openVideo();	//if successful return 1, else return 0
int closeVideo();
#endif //__V4LGRAB_H___

