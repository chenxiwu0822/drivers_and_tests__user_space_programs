/* example.c*/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void thread(void)
{
	int i;
	for(i=0;i<3;i++)
		printf("This is a pthread. \n");
}

int main(void)
{
	pthread_t id;
	int i,ret;

	ret=pthread_create(&id,NULL,(void *) thread,NULL);
	if(ret!=0){
		printf ("Create pthread error! \n");
		exit (1);
	}

	for(i=0;i<3;i++)
		printf("This is the main process. \n");

	pthread_join(id,NULL);
	return (0);
}
/*
编译：
gcc xxxxx.c -lpthread -o example_1

运行example_1，得到如下结果：
This is the main process.
This is a pthread.
This is the main process.
This is the main process.
This is a pthread.
This is a pthread.

再次运行，可能得到如下结果：
This is a pthread.
This is the main process.
This is a pthread.
This is the main process.
This is a pthread.
This is the main process.

前后两次结果不一样，这是两个线程争夺CPU资源的结果。
*/
