/*
编译： 注意选项
gcc xxxxx.c -lpthread -o example_1

运行example_1，得到如下结果：
This is the main process.
This is a pthread.
This is the main process.
This is the main process.
This is a pthread.
This is a pthread.

再次运行，可能得到如下结果：
This is a pthread.
This is the main process.
This is a pthread.
This is the main process.
This is a pthread.
This is the main process.

前后两次结果不一样，这是两个线程争夺CPU资源的结果。
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void thread1(void)
{
	int i;
	//for(i=0;i<3;i++)
	while(1) {
		printf("This is a pthread 1. \n");
		sleep(1);
	}
}

void thread2(void)
{
	int i;
	//for(i=0;i<3;i++)
	while(1) {
		printf("This is a pthread 2. \n");
		sleep(1);
	}
}

int main(void)
{
	pthread_t id1, id2;
	int i, ret;

	ret=pthread_create(&id1, NULL, (void *) thread1, NULL);
	if( ret != 0 ) {
		printf ("Create pthread 1 error! \n");
		exit (1);
	}

	ret=pthread_create(&id2, NULL, (void *) thread2, NULL);
	if( ret != 0 ) {
		printf ("Create pthread 2 error! \n");
		exit (1);
	}

	for(i=0; i<3; i++)
		printf("This is the main process. \n");

	pthread_join(id1, NULL); //阻塞的方式等待指定的线程结束。当函数返回时，被等待线程的资源被收回。如果线程已经结束，那么该函数会立即返回。并且thread指定的线程必须是joinable的
	pthread_join(id2, NULL);
	return (0);
}

