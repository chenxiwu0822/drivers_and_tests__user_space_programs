#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
 

void *print_message_function( void *ptr );
void *print_message( void *ptr );
void *print(void *ptr);
int i=0; 

int flag=0;//使用该数的状态切换来表示线程切换
pthread_t thread1;
pthread_t thread3;

main()
{
    
     char *message1 = "Thread 1";     
     int  iret1;
     iret1 = pthread_create( &thread1, NULL, print_message_function, (void*) message1); 
     pthread_join( thread1, NULL); 
      printf("整个程序退出!/n")   ; 
     exit(0);
}
 
void *print_message_function( void *ptr )
{
	time_t cur1, cur2;
	char *message;

	cur1=time(NULL);
	message = (char *) ptr;

	printf("%s /n", message);
	int iret3;
	flag=11;
	iret3=pthread_create( &thread3, NULL, print, "my name is shiguanghu");
	sleep(10);//模拟具体的业务逻辑，假设需要执行10秒钟
	flag=0;
	cur2=time(NULL);
	printf("函数print_message_function执行时间是%ld秒 /n",cur2-cur1); 
	pthread_join(thread3,NULL);  
}

void *print(void *ptr)
{
	printf("flag=%d ,退出!%s/n",flag,(char *)ptr);
	sleep(2);//这里的2就是timeout设定值
	if(flag)
	pthread_cancel(thread1);
}

 
/*
输出为：
[root@localhost PosixThread]# mytimer
Thread 1
flag=11 ,退出!my name is shiguanghu
整个程序退出!

说明线程1提前退出了，原因在于其执行时间为10秒钟超过了在线程3钟设定的timeout值2秒钟，实际上，程序正是只执行了两秒钟多就退出了（两秒是处理业务逻辑时间，多是其他程序执行时间）
*/
