/*


*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
 

void *print_message_function( void *ptr );
void *print_message( void *ptr );
void *print(void *ptr);
int i=0; 

int flag=0;	//使用该数的状态切换来表示线程切换
pthread_t thread1;
pthread_t thread3;

main()
{
    
     char *message1 = "Thread 1";     
     int  iret1;
     iret1 = pthread_create( &thread1, NULL, print_message_function, (void*) message1); 
     pthread_join( thread1, NULL); 
      printf("整个程序退出!/n")   ; 
     exit(0);
}
 
void *print_message_function( void *ptr )
{
 time_t cur1,cur2;
 cur1=time(NULL);
 char *message;
 message = (char *) ptr;
 printf("%s /n", message);
 int iret3;
 flag=11;
 iret3=pthread_create( &thread3, NULL, print, "my name is 007");
 sleep(2);//模拟具体的业务逻辑，假设需要执行10秒钟
 flag=0;
 cur2=time(NULL);
 printf("函数print_message_function执行时间是%ld秒 /n",cur2-cur1); 
 pthread_join(thread3,NULL);  
}
 void *print(void *ptr)
{
 printf("flag=%d ,退出!%s/n",flag,(char *)ptr);
 sleep(10);//这里的2就是timeout设定值
 if(flag)
 pthread_cancel(thread1);
}

 

[root@localhost PosixThread]# mytimer
Thread 1
flag=11 ,退出!my name is 007
函数print_message_function执行时间是2秒
整个程序退出!

 

可见设置的timeout为10秒钟竟然比处理业务逻辑的时间好要长，业务逻辑不干了，只需要等自己执行完毕（时长2秒钟）就退出了

 

 

以上程序只是简单的模拟了定时器思想，但是毫无疑问，它实现了定时器的两反面逻辑（超时该怎么办吗，没有超时该怎么办），我们可以进一步将它进行封装，并提供对外设置timeout值，业务逻辑入口等对外接口，就可以成为自己的定时器，以后调用起来就很方便了。


