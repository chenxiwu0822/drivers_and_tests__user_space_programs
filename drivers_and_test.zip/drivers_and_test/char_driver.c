#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/spi/spi.h>
#include <linux/gpio.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/uaccess.h>

#include "aube_transfer_info.h"
#include "aube_boot_loader.h"
#include "aube_main_fw.h"

#define DEV_NAME "aube"
#define AUBE_IRQ_TYPE IRQF_TRIGGER_FALLING
#define BUFFER_SIZE_TR 256
#define BUFFER_SIZE_BT 4736
#define BUFFER_SIZE_MF 31088
#define	AUBE_READY_PIN 92

int irqn;
u8 *tx_buf_transfer_info;
u8 *tx_buf_boot_loader;
u8 *tx_buf_main_fw;

static volatile int condition;
static DECLARE_WAIT_QUEUE_HEAD(aube_waitq);

static struct fasync_struct *aube_async;
struct spi_device *aube_spi_slv;
static int	aube_step;

struct aube_dev_t
{
    dev_t id;
    struct cdev cdev;
    struct class *class;
    struct device *dev;
} *aube_dev;

static int spi_test_transfer(struct spi_device *spi, const u8* buf, unsigned len)
{
	struct spi_transfer	t = {
			.tx_buf		= buf,
			.len		= len,
		};
	struct spi_message	m;

	spi_message_init(&m);
	spi_message_add_tail(&t, &m);
	return spi_sync(spi, &m);
}

static int init_spi_buffer(void)
{
	int	i;

	tx_buf_transfer_info = kmalloc(BUFFER_SIZE_TR, GFP_ATOMIC);
	if(tx_buf_transfer_info == NULL){
		pr_err("aube %s: mem alloc failed(transfer_info).\n", __func__);
		return -ENOMEM;
	}
	for (i=0; i<BUFFER_SIZE_TR; i++) {
		tx_buf_transfer_info[i] = tx_transfer_info[i];
	}

	tx_buf_boot_loader = kmalloc(BUFFER_SIZE_BT, GFP_ATOMIC);
	if(tx_buf_boot_loader == NULL){
		pr_err("aube %s: mem alloc failed(boot_loader).\n", __func__);
		return -ENOMEM;
	}
	for (i=0; i<BUFFER_SIZE_BT; i++) {
		tx_buf_boot_loader[i] = tx_boot_loader[i];
	}

	tx_buf_main_fw = kmalloc(BUFFER_SIZE_MF, GFP_ATOMIC);
	if(tx_buf_main_fw == NULL){
		pr_err("aube %s: mem alloc failed(main_fw).\n", __func__);
		return -ENOMEM;
	}
	for (i=0; i<BUFFER_SIZE_MF; i++) {
		tx_buf_main_fw[i] = tx_main_fw[i];
	}

	return 0;
}

static irqreturn_t aube_int_handler(int irq, void *dev_id)
{
	printk(KERN_EMERG"jiffies %lu: aube irq %d has come!\n", jiffies, irq );

	kill_fasync (&aube_async, SIGIO, POLL_IN);	//send SIGNAL to Userspace pid.

//	condition = 1;
//	wake_up_interruptible(&aube_waitq);

	return IRQ_HANDLED;
}

static int spi_test_probe(struct spi_device *spi)
{
	int err;
	aube_spi_slv = spi;
	spi_setup(spi);
	err = init_spi_buffer();

	err = gpio_request_one(AUBE_READY_PIN, GPIOF_DIR_IN, "aube_spi_ready_pin");
	if (err)
		pr_err(KERN_ERR"aube: Unable to aube_spi_ready_pin request!\n");

#if 0
	condition = 0;
	pr_info("------------ aube firmware init Start ------------\n");
	pr_info("send [transfer_info] return %d\n", spi_test_transfer(spi, tx_buf_transfer_info, BUFFER_SIZE_TR));
	wait_event_interruptible(aube_waitq, condition);	//if condition = 0, sleep.

	condition = 0;
	pr_info("send [boot_loader] return %d\n", spi_test_transfer(spi, tx_buf_boot_loader, BUFFER_SIZE_BT));
	wait_event_interruptible(aube_waitq, condition);

	condition = 0;
	pr_info("send [main_fw] return %d\n", spi_test_transfer(spi, tx_buf_main_fw, BUFFER_SIZE_MF));
	pr_info("------------ aube firmware init End ------------\n");
#endif
	return err;
}


static int aube_open(struct inode *inode, struct file *filp)
{
    int err;
    pr_info("aube open\n");
    err = request_irq(gpio_to_irq(AUBE_READY_PIN), aube_int_handler,  AUBE_IRQ_TYPE, "aube_int", NULL);
    return 0;
}

static ssize_t aube_read(struct file *filp, char __user *buf, size_t size,
							loff_t *offset)
{
    pr_info("aube read\n");
    return 0;
}

static ssize_t aube_write(struct file *filp, const char __user *u_buf,
							size_t size, loff_t *offset)
{
	int err;
	void *k_buf;

	pr_info("aube write\n");

	k_buf = kmalloc(size, GFP_KERNEL);
	if (!k_buf)
		return -ENOMEM;

	err = copy_from_user(k_buf, u_buf, size);
	if (err) {
		kfree(k_buf);
		return -EFAULT;
	}

	err = spi_test_transfer(aube_spi_slv, k_buf, size);
	if (!err) {
		pr_info("jiffies %lu: send [xxx] ok.\n", jiffies);
		kfree(k_buf);
	}

  return size;
}

static long aube_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	int err;
    pr_info("aube ioctl cmd %d arg %ld\n", cmd, arg);

#if 0
	switch(cmd) {
		case 1:	//aube firmware init
				irqn = gpio_to_irq(AUBE_READY_PIN);		//irqn = gpio_to_irq(platform_data->irq_gpio);
				err = request_irq(irqn, aube_int_handler,  AUBE_IRQ_TYPE, "aube_int", NULL);
				if (err) {
					pr_err(KERN_ERR "aube: Unable to register irq.\n");
					goto out_err;
				}

				if (aube_step == 0) {
					condition = 0;
					pr_info("------------ aube firmware init Start ------------\n");
					pr_info("jiffies %lu: send [transfer_info] return %d\n", jiffies, spi_test_transfer(aube_spi_slv, tx_buf_transfer_info, BUFFER_SIZE_TR));
					wait_event_interruptible(aube_waitq, condition);
					aube_step = 1;
					msleep(21);
				}

				if (aube_step == 1) {
					condition = 0;
					pr_info("jiffies %lu: send [boot_loader] return %d\n", jiffies, spi_test_transfer(aube_spi_slv, tx_buf_boot_loader, BUFFER_SIZE_BT));
					wait_event_interruptible(aube_waitq, condition);
					aube_step = 2;
					msleep(21);
				}

				if (aube_step == 2) {
					condition = 0;
					pr_info("jiffies %lu: send [main_fw] return %d\n", jiffies, spi_test_transfer(aube_spi_slv, tx_buf_main_fw, BUFFER_SIZE_MF));
					pr_info("------------ aube firmware init End ------------\n");
					aube_step = 0;
					free_irq(irqn, NULL);
				}
			break;
		default:
			break;
	}
#endif
    return 0;
out_err:
	gpio_free(AUBE_READY_PIN);
	return err;
}

static int aube_fasync(int fd, struct file *filp, int on)
{
	printk("jiffies %lu: %s -----> fasync_helper.\n", jiffies, __func__);
	return fasync_helper (fd, filp, on, &aube_async);	//kernel func: fasync_helper
}

#if 0
static unsigned aube_poll(struct file *file, poll_table *wait)
{
	unsigned int mask = 0;
	poll_wait(file, &aube_waitq, wait); //

	if (condition)
		mask |= POLLIN | POLLRDNORM;
	return mask;
}
#endif


struct file_operations aube_fops = {
    .owner          = THIS_MODULE,
    .open           = aube_open,
    //.release      = aube_close,
    .read           = aube_read,
    .write          = aube_write,
    .unlocked_ioctl = aube_ioctl,
	.fasync			= aube_fasync,	//UserSpace change FASYNC flag
	//.poll    		= aube_poll,
};

static struct spi_driver aube_spi_driver = {
	.driver = {
		.name = "sony_aube",
		.owner = THIS_MODULE,
	},
	.probe = spi_test_probe,
};

static int __init aube_init(void)
{
    int err;

    pr_info("%s:init\n", DEV_NAME);

    aube_dev = kmalloc(sizeof(struct aube_dev_t), GFP_KERNEL);
    if (!aube_dev) {
        pr_err("aube kmalloc err\n");
        return -ENOMEM;
    }

    err = alloc_chrdev_region(&aube_dev->id, 0, 1, DEV_NAME);
    if (err) {
        pr_err("aube alloc_chrdev_region err %d\n", err);
        goto out_free;
    }

    cdev_init(&aube_dev->cdev, &aube_fops);
    aube_dev->cdev.owner = THIS_MODULE;

    err = cdev_add(&aube_dev->cdev, aube_dev->id, 1);
    if (err) {
        pr_err("aube cdev_add err %d\n", err);
        goto out_unregister;
    }

    aube_dev->class = class_create(THIS_MODULE, DEV_NAME);
    if (IS_ERR(aube_dev->class)) {
        err = PTR_ERR(aube_dev->class);
        pr_err("aube class_create err %d\n", err);
        goto out_cdev_del;
    }

    aube_dev->dev = device_create(aube_dev->class, NULL,
            								aube_dev->id, NULL, DEV_NAME);
    if (IS_ERR(aube_dev->dev)) {
        err = PTR_ERR(aube_dev->dev);
        pr_err("aube device_create err %d\n", err);
        goto out_class_destroy;
    }

	spi_register_driver(&aube_spi_driver);

    return 0;

out_class_destroy:
    class_destroy(aube_dev->class);

out_cdev_del:
    cdev_del(&aube_dev->cdev);

out_unregister:
    unregister_chrdev_region(aube_dev->id, 1);

out_free:
    kfree(aube_dev);

    return err;
}

static void __exit aube_exit(void)
{
    pr_info("exit\n");
	free_irq(irqn, NULL);
	gpio_free(AUBE_READY_PIN);
	spi_unregister_driver(&aube_spi_driver);

    device_destroy(aube_dev->class, aube_dev->id);
    class_destroy(aube_dev->class);
    cdev_del(&aube_dev->cdev);
    unregister_chrdev_region(aube_dev->id, 1);
    kfree(aube_dev);
}

module_init(aube_init);
module_exit(aube_exit);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("kernel module aube");
