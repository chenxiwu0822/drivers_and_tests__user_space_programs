#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/mutex.h>
#include <linux/list.h>
#include <asm/uaccess.h>

#ifdef DEBUG
# define fop_pr_dbg(...)					\
	do {							\
		printk(KERN_DEBUG "%s: ", __FUNCTION__);	\
		printk(KERN_CONT __VA_ARGS__);			\
	} while (0)
#else
# define fop_pr_dbg(...) /* Do nothing */
#endif

static LIST_HEAD(fop_buffer_list);
static DEFINE_MUTEX(fop_buffer_list_mutex);

#define FOP_BUFFER_SIZE 4096

/** Buffer bind each struct inode. */
struct fop_buffer {
	struct list_head list;
	struct inode *inode;
	unsigned char *data;
	size_t alloc_size;
	size_t data_size;
	struct mutex mutex;
};

static inline void fop_list_add(struct fop_buffer *buffer)
{
	mutex_lock(&fop_buffer_list_mutex);
	list_add(&buffer->list, &fop_buffer_list);
	mutex_unlock(&fop_buffer_list_mutex);
}

static inline void fop_list_del(struct fop_buffer *buffer)
{
	mutex_lock(&fop_buffer_list_mutex);
	list_del(&buffer->list);
	mutex_unlock(&fop_buffer_list_mutex);
}

static inline struct fop_buffer *file_buffer(struct file *file)
{
	return (struct fop_buffer *)file->private_data;
}

static inline void buffer_file(struct file *file, struct fop_buffer *buffer)
{
	file->private_data = (void *)buffer;
}

static inline struct fop_buffer *inode_buffer(struct inode *inode)
{
	return (struct fop_buffer *)inode->i_private;
}

static inline void buffer_inode(struct inode *inode, struct fop_buffer *buffer)
{
	inode->i_private = (void *)buffer;
}

static struct fop_buffer *fop_alloc_buffer(struct inode *inode, size_t size)
{
	struct fop_buffer *buffer;

	buffer = vmalloc(sizeof(*buffer));
	if (!buffer)
		return NULL;

	buffer->data = vmalloc(size);
	if (!buffer->data)
		goto err;

	buffer->alloc_size = size;
	buffer->data_size = 0;
	mutex_init(&buffer->mutex);
	buffer_inode(inode, buffer);
	buffer->inode = inode;
	fop_list_add(buffer);
	return buffer;

err:
	vfree(buffer);
	return NULL;
}

static void fop_free_buffer(struct fop_buffer *buffer)
{
	fop_list_del(buffer);
	mutex_destroy(&buffer->mutex);
	buffer_inode(buffer->inode, NULL);
	vfree(buffer->data);
	vfree(buffer);
}

static ssize_t fop_read(struct file *file, char __user *buf, size_t count, loff_t *pos)
{
	struct fop_buffer *buffer = file_buffer(file);
	ssize_t size = 0, start;

	mutex_lock(&buffer->mutex);

	if (*pos != 0)
		start = *pos;
	else
		start = 0;

	/** tail -f needs fstat which is defined filesystem */
	if (start >= buffer->data_size)
		goto out;

	if (start + count >= buffer->data_size)
		size = buffer->data_size - start;
	else
		size = count;

	if (unlikely(copy_to_user(buf, buffer->data + start, size))) {
		mutex_unlock(&buffer->mutex);
		return -EFAULT;
	}

out:
	mutex_unlock(&buffer->mutex);

	*pos += size;
	return size;
}

static ssize_t fop_write(struct file *file, const char __user *buf, size_t count, loff_t *pos)
{
	struct fop_buffer *buffer = file_buffer(file);
	ssize_t size, start;

	mutex_lock(&buffer->mutex);

	if (*pos != 0)
		start = *pos;              /** open -> write -> write ... case */
	else if (file->f_flags & O_APPEND)
		start = buffer->data_size; /** open(O_APPEND) -> write case */
	else
		start = 0;                 /** open(not O_APPEND) -> write case */

	if (start + count >= buffer->alloc_size)
		size = buffer->alloc_size - start;
	else
		size = count;

	if (unlikely(copy_from_user(buffer->data + start, buf, size))) {
		mutex_unlock(&buffer->mutex);
		return -EFAULT;
	}

	if (start != 0)
		buffer->data_size += size;
	else
		buffer->data_size = size;

	mutex_unlock(&buffer->mutex);

	*pos += size;
	return size;
}

static int fop_open(struct inode *inode, struct file *file)
{
	struct fop_buffer *buffer;

	/** Device node is deleted and then new device node which has same path
	    is created and new buffer will be allocated. */
	buffer = inode_buffer(inode);
	if (!buffer) {
		buffer = fop_alloc_buffer(inode, FOP_BUFFER_SIZE);
		if (!buffer)
			return -ENOMEM;
	}

	buffer_file(file, buffer);
	return 0;
}

static int fop_close(struct inode *inode, struct file *file)
{
	buffer_file(file, NULL);
	return 0;
}

static struct file_operations fop_fops = {
	.owner = THIS_MODULE,
	.read = fop_read,
	.write = fop_write,
	.open = fop_open,
	.release = fop_close,
};

static struct miscdevice fop_dev = {
	.minor = MISC_DYNAMIC_MINOR,
	.name  = "fop",
	.fops  = &fop_fops,
};

static __init int fop_init(void)
{
	return misc_register(&fop_dev);
}

static __exit void fop_exit(void)
{
	while (!list_empty(&fop_buffer_list)) {
		struct fop_buffer *buffer = list_entry(fop_buffer_list.next,
						       struct fop_buffer, list);
		fop_free_buffer(buffer);
	}
	misc_deregister(&fop_dev);
}

module_init(fop_init);
module_exit(fop_exit);
