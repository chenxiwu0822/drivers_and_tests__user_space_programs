package com.friendlyarm.camerademo.ImageShow;

/**
 * @author dlion
 *
 */
public class FileLoadTask {

}
