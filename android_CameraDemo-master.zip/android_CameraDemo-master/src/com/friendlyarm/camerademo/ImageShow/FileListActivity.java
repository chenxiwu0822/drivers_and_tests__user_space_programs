package com.friendlyarm.camerademo.ImageShow;

import android.app.Activity;
import android.os.Bundle;

/**
 * @author dlion
 * 
 */
public class FileListActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
