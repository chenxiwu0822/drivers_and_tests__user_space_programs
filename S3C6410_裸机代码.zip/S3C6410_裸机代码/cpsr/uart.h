void putchar(char c);
char getchar(void);
void init_uart(void);


